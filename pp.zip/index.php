<?php

include_once 'detect.php';

$dt = date("l, F j Y | h:i:s A");

$msg = "
User-Agent : ".$user_agent."
IP : ".$ip." | Negara : ".$nama_negara." | Kota : " . $kota . " | State : " . $state . " | ".$dt."
";

$file=fopen("data_ip_masuk.txt","a");
fwrite($file, $msg);
fclose($file);
header("location: signin");
exit;

?>